﻿namespace PrimaryClasses
{
    public class Developer : Person { }
}
