﻿namespace PrimaryClasses
{
    public class Engineer : Person { }


}
