﻿namespace PrimaryClasses
{
    public class WebDeveloper : Developer { }


}
